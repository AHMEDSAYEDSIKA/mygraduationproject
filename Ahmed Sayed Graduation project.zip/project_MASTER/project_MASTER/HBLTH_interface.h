/*****************************************************************************/
/* File name: HBLTH_interface.h                                               */
/* Author: Ahmed Sayed   								 			  	      */
/* Description: This file contains the interfacing information of BLTH Module */
/*****************************************************************************/

/*Header file guard*/
#ifndef HBLTH_INTERFACE_H_
#define HBLTH_INTERFACE_H_

/************************************************************************/
/*                          Interfacing macros                          */
/************************************************************************/




/************************************************************************/
/*                          Functions' prototypes                       */
/************************************************************************/

/*this function is responsible for initializing the BLTH module */
void hblth_init(void);

/*this function sends one byte of data over the BLTH pripheral*/
void hblth_Blthsend(u8_t au8_databyte);

/*this function is responsible for receiving a byte of data from other BLTH pripheral*/
void hblth_Blthrecv(u8_t* pu8_databyte);



#endif /* HBLTH_INTERFACE_H_ */