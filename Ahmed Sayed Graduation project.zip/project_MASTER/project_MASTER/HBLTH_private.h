/*****************************************************************************/
/* File name: HBLTH_private.h                                                 */
/* Author: Ahmed Sayed													      */
/* Description: This file contains the private information of BLTH Module     */
/*****************************************************************************/

/*Header file guard*/
#ifndef HBLTH_PRIVATE_H_
#define HBLTH_PRIVATE_H_






#endif /* HBLTH_PRIVATE_H_ */