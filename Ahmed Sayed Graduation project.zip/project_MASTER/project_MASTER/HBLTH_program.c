/*****************************************************************************/
/* File name: HBLTH_program.c                                                 */
/* Author: Ahmed Sayed													     */
/* Description: This file contains the logical operations of BLTH Module      */
/*****************************************************************************/

/************************************************************************/
/*                             Includes                                 */
/************************************************************************/

#include "LBIT_MATH.h"
#include "LSTD_TYPES.h"
#include "MUART_interface.h"
#include "HBLTH_private.h"
#include "HBLTH_interface.h"

#define F_CPU 16000000UL
#include "util/delay.h"

/************************************************************************/
/*                          Important macros                            */
/************************************************************************/

#define TIMEOUT_DELAY (10)

/************************************************************************/
/*                          Functions' definitions                      */
/************************************************************************/

/*this function is responsible for initializing the BLTH module */
void hblth_init(void)
{
	/*initializing the UART to start with baud rate 9600 to communicate with the BLTH module*/
	muart_init(MUART_BAUDRATE_9600);
	
	/*returning from this function*/
	return;
}

/*this function sends one byte of data over the BLTH pripheral*/
void hblth_Blthsend(u8_t au8_databyte)
{
	/*sending the information received by the bluetooth to the master via UART protocol*/ 
	muart_senddataByte(au8_databyte);
	
	/*returning from this function*/
	return;
}

/*this function is responsible for receiving a byte of data from other BLTH pripheral*/
void hblth_Blthrecv(u8_t* pu8_databyte)
{
	/*receiving the information on the bluetooth coming from the master via UART protocol*/ 
	muart_recvdataByte(pu8_databyte);
	
	/*returning from this function*/
	return;
}
