/*****************************************************************************/
/* File name: MSPI_program.c                                                 */
/* Author: Ahmed Sayed												     */
/* Description: This file contains the logical operations of SPI Module      */
/*****************************************************************************/

/************************************************************************/
/*                             Includes                                 */
/************************************************************************/

#include "LBIT_MATH.h"
#include "LSTD_TYPES.h"
#include "MSPI_private.h"
#include "MSPI_interface.h"

#define F_CPU 16000000UL
#include "util/delay.h"

/************************************************************************/
/*                          Important' macros                           */
/************************************************************************/

#define TIMEOUT_DELAY (100)

/************************************************************************/
/*                          Functions' definitions                      */
/************************************************************************/

/*this function is used for initializing the SPI module*/
void mspi_init(u8_t au8_spiMode, u8_t au8_dataOutMode, u8_t au8_clockMode, u8_t au8_spiSpeed)
{
	/*clear the SPI control register*/
	MSPI_SPCR = 0;
	
	/*Check the SPI speed to set the SPI2X bit or not*/
	if((au8_spiSpeed % 2) == 0)
	{
		/*double the speed of the SPI*/
		SET_BIT(MSPI_SPSR,0);
	}
	else
	{
		/*Do nothing*/
	}
	
	/*set the control register and (0x40) enable the SPI peripheral*/
	MSPI_SPCR |= (0x40) | (au8_dataOutMode << 5) | (au8_spiMode << 4) | (au8_clockMode << 2) | (au8_spiSpeed / 2) ;
	
	/*returning from this function*/
	return;
}

/*this function for sending and receiving a byte of data as a master*/
void mspi_masterSendRecvByte(u8_t au8_senddata, u8_t* pu8_recvdata)
{
	/*timing out variable*/
	u8_t au8_timeout = 0;
	
	/*place the data on the SPI bus to send from master to slave*/
	MSPI_SPDR = au8_senddata;
	
	/*check if the transmission ends or not*/
	while((GET_BIT(MSPI_SPSR,7) == 0) && (au8_timeout < TIMEOUT_DELAY))
	{
		/*increment the time out variable*/
		au8_timeout++;
		
		/*delay for 1 microseconds*/
		_delay_us(1);
	}
	
	/*reading the data arrived from the slave*/
	*pu8_recvdata = MSPI_SPDR;
	
	/*returning from this function*/
	return;
}

/*this function for sending and receiving a byte of data as a slave*/
void mspi_slaveSendRecvByte(u8_t au8_senddata, u8_t* pu8_recvdata)
{
	/*place the data on the SPI bus to send from slave to master*/
	MSPI_SPDR = au8_senddata;
	
	/*check if there is any data come from master or not*/
	if(GET_BIT(MSPI_SPSR,7))
	{
		/*reading the data arrived from the master*/
		*pu8_recvdata = MSPI_SPDR;
	}
	else 
	{
		/*Do nothing*/
	}
	
	/*returning from this function*/
	return;
	
}

