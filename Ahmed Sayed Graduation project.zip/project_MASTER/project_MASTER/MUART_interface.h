/*****************************************************************************/
/* File name: MUART_interface.h                                               */
/* Author: Ahmed Sayed   								 			  	      */
/* Description: This file contains the interfacing information of UART Module */
/*****************************************************************************/

/*Header file guard*/
#ifndef MUART_INTERFACE_H_
#define MUART_INTERFACE_H_

/************************************************************************/
/*                          Interfacing macros                          */
/************************************************************************/

/*Baud rate register values at 16 MHZ*/
#define MUART_BAUDRATE_2400     (416)
#define MUART_BAUDRATE_4800     (207)
#define MUART_BAUDRATE_9600     (103)
#define MUART_BAUDRATE_19200    (51)
#define MUART_BAUDRATE_115200   (8)

/************************************************************************/
/*                          Functions' prototypes                       */
/************************************************************************/

/*this function is responsible for initializing the UART module with specific baud rate*/
void muart_init(u16_t au16_baudRate);

/*this function sends one byte of data over the UART pripheral*/
void muart_senddataByte(u8_t au8_databyte);

/*this function sends multiple bytes of data according to the data size*/
void muart_senddataStream(u8_t* pu8_datastream, u8_t au8_dataSize);

/*this function is responsible for receiving a byte of data from other UART pripheral*/
void muart_recvdataByte(u8_t* pu8_databyte);


#endif /* MUART_INTERFACE_H_ */