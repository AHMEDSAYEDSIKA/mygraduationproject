/*****************************************************************************/
/* File name: MUART_program.c                                                 */
/* Author: Ahmed Sayed													     */
/* Description: This file contains the logical operations of UART Module      */
/*****************************************************************************/

/************************************************************************/
/*                             Includes                                 */
/************************************************************************/

#include "LBIT_MATH.h"
#include "LSTD_TYPES.h"
#include "MUART_private.h"
#include "MUART_interface.h"

#define F_CPU 16000000UL
#include "util/delay.h"

/************************************************************************/
/*                          Important macros                            */
/************************************************************************/

#define TIMEOUT_DELAY (10)

/************************************************************************/
/*                          Functions' definitions                      */
/************************************************************************/

/*this function is responsible for initializing the UART module with specific baud rate*/
void muart_init(u16_t au16_baudRate)
{
	/*enable TX and RX pins of the UART with no interrupts*/
	MUART_UCSRB = 0x18;
	
	/*enable the asynchronus mode, no parity bit with 1 stop bit and one byte of data*/
	MUART_UCSRC = 0x86;
	
	/*setting the low baud rate register*/
	MUART_UBRRL = (u8_t)au16_baudRate;
	
	/*setting the high baud rate register*/
	MUART_UBRRH = (u8_t)(au16_baudRate >> 8);
	
	/*returning from this function*/
	return;	
}

/*this function sends one byte of data over the UART pripheral*/
void muart_senddataByte(u8_t au8_databyte)
{
	/*a variable to check the time out in the transmitting of data byte*/
	u8_t au8_timeout = 0;
	
	/*Check if the UDR register is empty or not*/
	if(GET_BIT(MUART_UCSRA,5))
	{
		/*transmit byte of data over UART*/
		MUART_UDR = au8_databyte;
		
		/*check if the transmission of the byte complete or not with specific delay*/
		while(GET_BIT(MUART_UCSRA,6) == 0 && au8_timeout < TIMEOUT_DELAY)
		{
			/*increment the time out variable*/
			au8_timeout++;
			
			/*delay for 1 ms*/
			_delay_ms(1);
		}
		
		/*Clearing the transmission complete bit to enable us to use the UDR register again*/
		SET_BIT(MUART_UCSRA,6);
	}
	
	/*if the UDR register is not empty*/
	else
	{
		/*Do nothing*/
	}

   /*returning from this function*/
    return;	
}

/*this function sends multiple bytes of data according to the data size*/
void muart_senddataStream(u8_t* pu8_datastream, u8_t au8_dataSize)
{
	/*variable for looping operation*/
	u8_t au8_loopingVar = 0;
	
	/*looping to send all the bytes of data according to its size*/
	while(au8_dataSize--)
	{
		/*send byte of data*/
		muart_senddataByte(pu8_datastream[au8_loopingVar]);
		
		/*increment the looping variable*/
		au8_loopingVar++;
	}
	
	 /*returning from this function*/
	 return;
}

/*this function is responsible for receiving a byte of data from other UART pripheral*/
void muart_recvdataByte(u8_t* pu8_databyte)
{
	/*check if there is receiving data byte in the UDR register or not*/
	if(GET_BIT(MUART_UCSRA,7))
	{
		/*Reading the byte of data received in the UDR register*/
		*pu8_databyte = MUART_UDR;
		
	}
	
	/*if there is no flag to the receive complete bit then there is no data received in UDR register*/
	else
	{
		/*Do nothing*/
	}
	
	/*returning from this function*/
	return;
	
}