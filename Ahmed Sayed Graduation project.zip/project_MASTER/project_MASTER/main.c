
#include "LBIT_MATH.h"
#include "LSTD_TYPES.h"
#include "MDIO_interface.h"
#include "MUART_interface.h"
#include "MSPI_interface.h"
#include "HBLTH_interface.h"

#define F_CPU 16000000UL
#include "util/delay.h"


int main(void)
{
	
	u8_t au8_data = 0;
	u8_t au8_recvbyte = 0;
	
	mdio_setPinStatus(PORTD, PIN0, INPUT_FLOAT);
	mdio_setPinStatus(PORTD, PIN1, OUTPUT);
	mdio_setPinStatus(PORTA, PIN0, OUTPUT);
	mdio_setPinStatus(PORTB, (PIN5 | PIN7) , OUTPUT);
    mdio_setPinStatus(PORTB, PIN6, INPUT_FLOAT);
	
	hblth_init();
	
	mspi_init(MSPI_MASTER_MODE, MSPI_MSB_FIRST, MSPI_SAMPLE_R_SETUP_F, MSPI_CLK_BY_16);
	
	mdio_setPinValue(PORTA, PIN0, LOW);
    /* Replace with your application code */
    while (1) 
    {
		hblth_Blthrecv(&au8_data);
		
		mspi_masterSendRecvByte(au8_data, &au8_recvbyte);
		_delay_us(100);	
    }
}

