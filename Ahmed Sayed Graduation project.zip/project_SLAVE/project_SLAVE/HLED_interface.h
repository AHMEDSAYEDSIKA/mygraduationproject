/*****************************************************************************/
/* File name: HLED_interface.h                                               */
/* Author: Ahmed Sayed										     		     */
/* Description: This file contains the interfacing information of LED Module */
/*****************************************************************************/

#ifndef HLED_INTERFACE_H_
#define HLED_INTERFACE_H_

/************************************************************************/
/*                          Interfacing macros                          */
/************************************************************************/
#define HLED_led1 (0)
#define HLED_led2 (1)

/************************************************************************/
/*                          Functions' prototypes                       */
/************************************************************************/
/*this function is responsible for initializing the LED module */
void hled_init(void);

/*this function to turn one of the two leds on*/
void hled_ledOn(u8_t au8_ledno);

/*this function to turn one of the two leds off*/
void hled_ledOff(u8_t au8_ledno);



#endif /* HLED_INTERFACE_H_ */