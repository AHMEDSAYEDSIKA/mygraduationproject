/*****************************************************************************/
/* File name: HLED_private.h                                                 */
/* Author: Ahmed Sayed  												     */
/* Description: This file contains the private information of LED Module     */
/*****************************************************************************/


#ifndef HLED_PRIVATE_H_
#define HLED_PRIVATE_H_




#endif /* HLED_PRIVATE_H_ */