/*****************************************************************************/
/* File name: HLED_program.c                                                 */
/* Author: Ahmed Sayed													     */
/* Description: This file contains the logical operations of LED Module      */
/*****************************************************************************/

/************************************************************************/
/*                             Includes                                 */
/************************************************************************/

#include "LBIT_MATH.h"
#include "LSTD_TYPES.h"
#include "MDIO_interface.h"
#include "HLED_private.h"
#include "HLED_interface.h"

/************************************************************************/
/*                          Functions' definitions                      */
/************************************************************************/

/*this function is responsible for initializing the LED module */
void hled_init(void)
{
	/*setting the led pins to output*/
	mdio_setPinStatus(PORTC,PIN2,OUTPUT);
	mdio_setPinStatus(PORTD,PIN3,OUTPUT);
	
	/*returning from this function*/
	return;
}

/*this function to turn one of the two leds on*/
void hled_ledOn(u8_t au8_ledno)
{
	/*switching over the selected leds*/
	switch(au8_ledno)
	{
		/*in the case of led 1*/
		case HLED_led1:
		
		/*turning on led 1*/
		mdio_setPinValue(PORTC,PIN2,HIGH);
		
		/*breaking from this case*/
		break;
		
		/*in the case of led 2*/
		case HLED_led2:
		
		/*turning on led 2*/
		mdio_setPinValue(PORTD,PIN3,HIGH);
		
		/*breaking from this case*/
		break;	
	}
	/*returning from this function*/
	return;
}

/*this function to turn one of the two leds off*/
void hled_ledOff(u8_t au8_ledno)
{
	/*switching over the selected leds*/
	switch(au8_ledno)
	{
		/*in the case of led 1*/
		case HLED_led1:
		
		/*turning off led 1*/
		mdio_setPinValue(PORTC,PIN2,LOW);
		
		/*breaking from this case*/
		break;
		
		/*in the case of led 2*/
		case HLED_led2:
		
		/*turning off led 2*/
		mdio_setPinValue(PORTD,PIN3,LOW);
		
		/*breaking from this case*/
		break;
	}
	
	/*returning from this function*/
	return;
}
