

#include "LBIT_MATH.h"
#include "LSTD_TYPES.h"
#include "MDIO_interface.h"
#include "MSPI_interface.h"
#include "HLED_interface.h"

#define F_CPU 16000000UL
#include "util/delay.h"

int main(void)
{
	
	u8_t au8_recbyte = 0;
	
	mdio_setPinStatus(PORTB, (PIN4|PIN5|PIN7), INPUT_FLOAT);
	mdio_setPinStatus(PORTB, PIN6, OUTPUT);
	
	hled_init();
	
    mspi_init(MSPI_SLAVE_MODE, MSPI_MSB_FIRST, MSPI_SAMPLE_R_SETUP_F, MSPI_CLK_BY_16);
	
	
    /* Replace with your application code */
    while (1) 
    {
		mspi_slaveSendRecvByte(0x40, &au8_recbyte);
		_delay_us(100);
		
		if(au8_recbyte == 'a')
		{
			hled_ledOn(HLED_led1);	
		}
		else if(au8_recbyte == 'b')
		{
			hled_ledOn(HLED_led2);	
		}
		else if(au8_recbyte == 'A')
		{
			hled_ledOff(HLED_led1);
		}
		else if(au8_recbyte == 'B')
		{
			hled_ledOff(HLED_led2);
		}
		else
		{
			/*Do nothing*/
		}
		
    }
}

